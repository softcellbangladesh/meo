<!-- Footer -->
    <footer class="bg-dark footer">
      <div class="container">
      	<div class="row">
	      	<div class="col-md-6">
	        	<div class="text-white">
		        	<!-- <ul class="nav nav-social">
					  <li class="nav-item">
					    <a class="nav-link" href="#"><i class="fab fa-facebook-square"></i></a>
					  </li>
					  <li class="nav-item">
					    <a class="nav-link" href="#"><i class="fab fa-twitter-square"></i></a>
					  </li>
					  <li class="nav-item">
					    <a class="nav-link" href="#"><i class="fab fa-google-plus-square"></i></a>
					  </li>
					</ul> -->
                    <div class="copyright">
	        		Copyright &copy; MEO CENTRAL 2018 By <a target="_blank" href="http://glitrabd.net">Glitra BD Ltd.</a>
	        		</div>
	        	</div>
	        </div>
	        <!-- <div class="col-md-6">
	        	<ul class="nav nav-right">
				  <li class="nav-item">
				    <a class="nav-link" href="#">WE ARE</a>
				  </li>
				  <li class="nav-item">
				    <a class="nav-link" href="#">MISSION</a>
				  </li>
				  <li class="nav-item">
				    <a class="nav-link" href="#">VISSION</a>
				  </li>
				  <li class="nav-item">
				    <a class="nav-link" href="#">NEWS</a>
				  </li>
				</ul>
	        </div> -->
	    </div>    
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!--JS-->
    <script src="<?php echo base_url() ?>assets/js/app.js"></script>

	<script src="<?php echo base_url() ?>assets/js/services/toaster.js"></script>
	<script src="<?php echo base_url() ?>assets/js/filters/utility.js"></script>

  </body>

</html>